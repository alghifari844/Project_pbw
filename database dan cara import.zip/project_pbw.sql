-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 07:44 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_pbw`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `judul` varchar(255) NOT NULL,
  `pengarang` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`judul`, `pengarang`, `deskripsi`) VALUES
('Baik luar dalam', 'alghi', '“Din, ada Devi tuh di depan nyariin kamu katanya, ditemuin gih. Dah nungguin dari tadi.” Sahut Devi kepada Dinda yang sedang mengerjakan tugas sekolah di rumah Dinda.\r\n\r\n“Bi surti, bilang aja aku gak ada, lagi keluar apa cari alasan lain gitu.” Pinta Dinda pada Bi Surti yang bekerja di rumahnya.\r\n\r\n“Iya, Non.”\r\n\r\n“Kamu kenapa kaya gitu sama Devi? Dia sudah datang jauh-jauh malah kamu gituin. Devi itu anak baik lho, Din.”\r\n\r\n“Iya dari memang luarnya keliatan baik, manis, ramah. Tapi apa hanya itu saja kamu mengukur sifat seseorang? Dari luar memang manis. Tapi dalamnya tuh pahit.”\r\n\r\n“Pahit gimana maksudnya?”\r\n\r\n“Devi itu sering ngomongin keburukan temannya sendiri di belakang orangnya. Banyak pokoknya, yang gak bisa aku jelasin ke kamu.\r\n\r\n“Beda sama kamu, lihatlah kamu ini. Judes, ceplas-ceplos kalo ngomong sama aku. Tapi hatimu tulus, Tin, bukan baik di luar tapi dalamnya busuk. Aku gak butuh kawan yang tampilan luar orang dalam berteman.” Jelas Dinda.'),
('piknik', 'agus noor', 'Para pelancong mengunjungi kota kami untuk menyaksikan kepedihan. Mereka datang untuk menonton kota kami yang hancur. Kemunculan para pelancong itu membuat kesibukan tersendiri di kota kami. Biasanya kami duduk-duduk di gerbang kota menandangi para pelancong yang selalu muncul berombongan mengendarai kuda, keledai, unta, atau permadani terbang dan juga kuda sembrani. Mereka datang dari segala penjuru dunia. Dari negeri-negeri jauh yang gemerlapan.\r\n\r\nDi bawah langit senja yang kemerahan kedatangan mereka selalu terlihat bagaikan siluet iring-iringan kafilah melintasi gurun perbatasan, membawa bermacam perbekalan piknik. Berkarung-karung gandum yang diangkut gerobak pedati, daging asap yang digantungkan di punuk unta terlihat bergoyang-goyang, roti kering yang disimpan dalam kaleng, botol-botol cuka dan saus, biskuit dan telor asin, rendang dalam rantang—juga berdus-dus mi instan yang kadang mereka bagikan pada kami.\r\n\r\nPenampilan para pelancong yang selalu riang membuat kami sedikit merasa terhibur. Kami menduga, para pelancong itu sepertinya telah bosan dengan hidup mereka yang sudah terlampau bahagia. Hidup yang selalu dipenuhi kebahagiaan ternyata bisa membosankan juga. Mungkin para pelancong itu tak tahu lagi bagaimana caranya menikmati hidup yang nyaman tenteram tanpa kecemasan di tempat asal mereka. Karena itulah mereka ramai-ramai piknik ke kota kami: menyaksikan bagaimana perlahan-lahan kota kami menjadi debu. Kami menyukai cara mereka tertawa, saat mereka begitu gembira membangun tenda-tenda dan mengeluarkan perbekalan, lalu berfoto ramai-ramai di antara reruntuhan puing-puing kota kami. Kami seperti menyaksikan rombongan sirkus yang datang untuk menghibur kami.\r\n\r\nKadang mereka mengajak kami berfoto. Dan kami harus tampak menyedihkan dalam foto-foto mereka. Karena memang untuk itulah mereka mengajak kami berfoto bersama. Mereka tak suka bila kami terlihat tak menderita. Mereka menyukai wajah kami yang keruh dengan kesedihan. Mata kami yang murung dan sayu. Sementara mereka sembari berdiri dengan latar belakang puing-puing reruntuhan kota— berpose penuh gaya tersenyum saling peluk atau merentangkan tangan lebar-lebar. Mereka segera mencetak foto-foto itu, dan mengirimkannya dengan merpati-merpati pos ke alamat kerabat mereka yang belum sempat mengunjungi kota kami.'),
('Sirkus', 'agus noor', 'ROMBONGAN sirkus itu muncul ke kota kami….\r\n\r\nGempita tetabuhan yang menandai kedatangan mereka membuat kami–anak-anak yang lagi asyik bermain jet-skateboard–langsung menghambur menuju gerbang kota. Rombongan sirkus itu muncul dari balik cakrawala. Debu mengepul ketika roda-roda kereta karnaval berderak menuju kota kami. Dari kejauhan panji-panji warna-warni terlihat meliuk-liuk mengikuti musik yang membahana. Dan kami berteriak-teriak gembira, “Sirkus! Sirkus! Horeee!!!”\r\n\r\nSungguh beruntung kami bisa melihat rombongan sirkus itu. Mereka seperti nasib  baik yang tak bisa diduga atau diharap-harapkan kedatangannya. Rombongan sirkus itu akan datang ke satu kota bila memang mereka ingin datang, menggelar pertunjukan semalam, kemudian segera melanjutkan perjalanan. Rombongan sirkus itu layaknya kafilah pengembara yang terus-menerus mengelilingi dunia, melintasi benua demi benua, menyeberangi lautan dan hutan-hutan, menembus waktu entah sejak kapan.\r\n\r\nKisah-kisah ajaib tentang mereka sering kami dengar, serupa dongeng yang melambungkan fantasi kami. Banyak yang percaya, sirkus itu ada sejak mula sabda. Merekalah arak-arakan sirkus pertama yang mengiringi perjalanan Adam dan Eva dari firdaus ke dunia. Mereka legenda yang terus hidup dari zaman ke zaman. Ada yang percaya. Ada yang tidak. Karena memang tak setiap orang pernah melihatnya. Sirkus itu tak akan mungkin kau temukan meskipun kau telah tanpa lelah terus memburunya hingga seluruh ceruk semesta. Bukan kau yang berhasil menemukan rombongan sirkus itu. Tapi merekalah yang mendatangimu. Dan itulah keberuntungan. Merekalah sirkus gaib berkereta nasib. Kau hanya dapat berharap diberkahi bintang terang untuk bisa melihatnya. Banyak orang hanya bisa mendengar gema gempita suara kedatangan mereka melintasi kota, tapi tak bisa melihat wujudnya. Orang-orang yang tak diberkati keberuntungan itu hanya mendengar suara arak-arakan mengapung di udara yang makin lama makin sayup menjauh….'),
('Lomba menari', 'alghi', 'Ani anak yang pandai selain pandai ia juga suka menari, di sekolah ada ekstrakulikuler menari, tentu Ani salah satu anggotanya. Hari ini, sepulang sekolah Ani ada latihan menari dengan ke tiga temannya untuk persiapan lomba lusa.\r\n\r\nKringgg… Bunyi bel pulang sekolah berdering semua anak keluar dari kelas untuk pulang kerumah masing masing, hanya beberapa anak yang masih disekolah untuk beberapa kegiatan. Diruang seni ada Ani, Rida, Cahya dan Mela mereka berempat yang terpilih mewakili sekolah untuk lomba menari lusa.\r\n\r\n“Da kamu sudah handle semua persiapan buat lusa kan?” tanya Ani pada Rida\r\n\r\n“Jangan khawatir Ani, tanteku bersedia untuk makeup kita” jawab Rida\r\n\r\n“Kalau begitu ayo kita latihan” ajak Cahya yang disetujui oleh teman temannya. Sudah satu bulan terakhir mereka selalu berlatih dengan bersungguh sungguh untuk mengharumkan nama sekolah.'),
('scrub gula pasir', 'alghi', 'Di siang hari, Lia sedang ngobrol santai dengan Andes terlihat sangat asyik pembicaraan mereka. “Ndes, menurutmu Dion itu suka tipe perempuan yang seperti apa?”. “Em, apa ya? Kalau aku terawang Dion sukanya perempuan santai yang gak banyak ulah. Ujar Andes. “Jadi gak suka cewe ginju?” Tanya Lia. “Maybe yes maybe no.” “Menurut kamu apa yang bisa menggantikan lipstik?”. “Coba kamu pake scrub gula pasir.”“Oya?”. ”Nanti malam ku coba demi sang pujaan hati adinda. Hahaha.” “Kan seminggu lagi ada bazar dikampus siapa tau ketemu Dion, scruban aja terus kamu tiap malam.” “Bener, harus tampil maksimal.” Tukas Lia mengiyakan. Beberapa hari sudah lewat. Di hari sebelum acara, Lia tampil seperti saran Andes, Andes kaget melihatnya. “Ada apa dengan bibir kamu Lia? Kenapa sangat merah ? Berapa kilo gula yang kamu gunakan  ? Ujar Andes menahan tawa. “Ini gigitan semut tiap malam tauu, perjuangan gara gara scrub fula pasir.” Jawab Lia.“Oh My Good”. Teriak Andes tertawa terpingkal-pingkal.'),
('tak konsisten', 'alghi', 'Suara alarm berdering begitu nyaring mengusik tidur nyenyak seorang Nathan. Dia enggan membuka mata namun akhirnya terpaksa ia buka.\r\n\r\n“Oh Tuhan!” Nathan kaget melihat jam ternyata sekarang sudah pukul 7 pagi. Nathan langsung bergegas mandi dan tanpa sarapan ia berangkat kekantor. Sesampainya Nathan di kantor, Nathan telat mengikuti pertemuan pagi ini karena telah dimajukan lebih awal dari biasanya dengan alasan Bapak Direktur ada keperluan diluar kota.\r\n\r\n“Permisi, Pak. Saya Boleh masuk?” Tanya Nathan izin kepada bapak direktur yang memimpin pertemuan.\r\n\r\n”Silakan masuk, tapi maaf proyekmu digantikan oleh saudara Arkan.”\r\n\r\n“Kenapa pak? Saya hanya telat 15 menit.”\r\n\r\n“Maaf saudara Nathan ini bukan masalah lama atau tidaknya anda terlambat, namun ini tentang ke konsistenan anda dalam bekerja.” Jelas Bapak direktur  dengan tegas.\r\n\r\nLangsung seketika Nathan hanya bisa terdiam dengan wajah pucatnya. Setelah pertemuan ini selesai Nathan berjalan gontai pergi menuju meja kerja miliknya.');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('fari@gmail.com', '$2y$10$i53Y8EMxQ64mgrUTolADT.63iyHTAI2H1ANOBB4BGPvEXxmvZdsiS', '2020-05-04 22:35:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'alghi', 'fari@gmail.com', NULL, '$2y$10$bhiOLfhppxy1OdvgK4GDFuwj3WSD6ixgBG5U1k2L9edEwOYvgKQ0m', NULL, '2020-05-04 05:16:06', '2020-05-04 05:16:06'),
(2, 'agus noor', 'agus@gmail.com', NULL, '$2y$10$JKaflbnwBTCevVOzDGwleuLwmfcAb5BxXRwmCa4VW/llSpmN9dFhm', NULL, '2020-05-04 14:59:05', '2020-05-04 14:59:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
